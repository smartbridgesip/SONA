package com.sona.vikashmurali.liverdiseaseanalysis;

import android.content.Context;
import android.os.AsyncTask;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
//import java.util.Base64;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;


public class data_flow extends AsyncTask<String,Void,String> {
    private Context context;
    public data_flow(Context context) {
        this.context = context;
    }
    HttpURLConnection urlConnection;

    @Override
    protected String doInBackground(String... strings) {
        String access_token="";
        String usernameColonPassword = "92f5baa6-848f-4258-a65a-ecaf7a761eec:2ce40f39-b646-47ae-81b0-c9d1c9711bb5";
        String basicAuthPayload = "Basic " + Base64.encode(usernameColonPassword.getBytes(),Base64.DEFAULT);

        BufferedReader httpResponseReader = null;
        try {
            // Connect to the web server endpoint
            URL serverUrl = new URL("https://eu-gb.ml.cloud.ibm.com/v3/identity/token");
            HttpURLConnection urlConnection = (HttpURLConnection) serverUrl.openConnection();

            // Set HTTP method as GET
            urlConnection.setRequestMethod("GET");

            // Include the HTTP Basic Authentication payload
            urlConnection.addRequestProperty("Authorization", basicAuthPayload);

            // Read response from web server, which will trigger HTTP Basic Authentication request to be sent.
            httpResponseReader =
                    new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String lineRead;
            while((lineRead = httpResponseReader.readLine()) != null) {
                System.out.println(lineRead);
            }

        } catch (IOException ioe) {
            ioe.printStackTrace();


        } finally {

            if (httpResponseReader != null) {
                try {
                    httpResponseReader.close();
                } catch (IOException ioe) {
                    // Close quietly
                }
            }
        }
        //prediction value send-----------------
       try {
            Log.d("starting","starting predict values");

            //String access_token="eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRJZCI6ImRjMjlhZjZkLWRjYjgtNDg0Ni1hYTJiLTZlYjJiOWY4NmFiZSIsImluc3RhbmNlSWQiOiJkYzI5YWY2ZC1kY2I4LTQ4NDYtYWEyYi02ZWIyYjlmODZhYmUiLCJwbGFuSWQiOiIzZjZhY2Y0My1lZGU4LTQxM2EtYWM2OS1mOGFmM2JiMGNiZmUiLCJyZWdpb24iOiJldS1nYiIsInVzZXJJZCI6ImQxYTdjZmU3LTczOWUtNDFlMi1iMzVjLTE0NWNkMTY4YWM0ZSIsImlzcyI6Imh0dHBzOi8vZXUtZ2IubWwuY2xvdWQuaWJtLmNvbS92My9pZGVudGl0eSIsImlhdCI6MTU2MTcxNDU3NywiZXhwIjoxNTYxNzQzMzc3LCJjcmVhdGVkVGltZSI6MTU2MTcxNDU3N30.ZkJ-nbqvxaGAZadwgeBeCwWOhUDBrNvHJ5RPzJVhjnq8bmF-kr5H9dCdZaPzBVA_w7ifsYjjK1DBKAvovNiBVaQIQ5zOTjl868iVT5zWs0Nhulq2-xb9NMyzUVXZG6ysWgpGNilZzQ1wAWz9A_3MaGXrSMuZFu9mzmiVzk-IpneSSACF3yWZD6rZHOjxDwkG22g_EPfODrn1RvPua5FpWkBWbLJyfFL65xFliypPPf5JaZWAugypgfBuCfVFrrB_FgzVWX2fjXbkhCHiq-KOneGZS9HT0IrusjXxi6mjjwBWbt_wCTvHO3BTIBZ3hWgNakMNLcieGIUXzBqZeQL9Ug";
            String url = "https://eu-gb.ml.cloud.ibm.com/v3/wml_instances/9adae679-afe4-458a-b880-e9a8e6e173db/deployments/aea9c42b-e9af-461c-8acd-cc35326ec33c/online";
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            // optional default is GET
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            con.setRequestProperty("Authorization", "Bearer "+ access_token);
            con.setDoOutput(true);
            String a="{"+"\"fields\":[\"Gender\",\"Age\",\"Total_Bilirubin\",\"Direct_Bilirubin\",\"Alkaline_Phosphotase\",\"Alamine_Aminotransferase\",\"Aspartate_Aminotransferase\"],\"values\":[[0,20,10,1.1,2.5,5.4,9.1]}";
            byte[] input = a.getBytes("utf-8");
            OutputStream os = con.getOutputStream();

            os.write(input);

            int responseCode = con.getResponseCode();
            //System.out.println("\nSending 'POST' request to URL : " + url);
            //System.out.println("Response Code : " + responseCode);
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream(), "utf-8"));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            //print result
            //System.out.println(response.toString());


            // below code converts the json response to json object and reads each values
            JSONObject jsonObj = new JSONObject();
            String value="";
            try {
                 value=jsonObj.getString("");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            //Toast.makeText(this,value.toString(), Toast.LENGTH_LONG).show();
            //System.out.println(jsonObj.getString("id"));
            //System.out.println(jsonObj.getString("name"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
    }
}
