package com.sona.vikashmurali.liverdiseaseanalysis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class doctor_login extends AppCompatActivity {
    EditText et1;
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_login);
        et1=(EditText)findViewById(R.id.doctor_id);
        tv1=(TextView)findViewById(R.id.login_errord);

    }

    public void doc_login(View view) {
        if(et1.getText().toString().equalsIgnoreCase("doctor")){
            Intent intent= new Intent(getApplicationContext(),doctor_show.class);
            startActivity(intent);
        }
        else{
            tv1.setText("Invalid doctor ID!");
        }
    }
}

