package com.sona.vikashmurali.liverdiseaseanalysis;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class doctor_show extends AppCompatActivity {
    TextView allrecordshow;
    myDbAdapter helper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_show);
        helper = new myDbAdapter(this);
        allrecordshow=(TextView)findViewById(R.id.doc_show);
        view_data();
    }

    private void view_data() {
        String data = helper.getData_docter();
        allrecordshow.setText(data);
    }
}
