package com.sona.vikashmurali.liverdiseaseanalysis;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.view.View;


public class myDbAdapter {
    myDbHelper myhelper;
    public myDbAdapter(Context context)
    {
        myhelper = new myDbHelper(context);
    }

    public long insertData(String ipid,Float age, Float gender, Float tot_bil, Float dir_bil, Float alk_pho, Float ala_amino, Float asp_amino, String result)
    {
        System.out.println("insert data"+result);
        SQLiteDatabase dbb = myhelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(myDbHelper.UID, ipid);
        contentValues.put(myDbHelper.AGE, age);
        contentValues.put(myDbHelper.GENDER, gender);
        contentValues.put(myDbHelper.TOT_BIL, tot_bil);
        contentValues.put(myDbHelper.DIR_BIL, dir_bil);
        contentValues.put(myDbHelper.ALK_PHO, alk_pho);
        contentValues.put(myDbHelper.ALA_AMINO, ala_amino);
        contentValues.put(myDbHelper.ASP_AMINO, asp_amino);
        contentValues.put(myDbHelper.RESULT, result);

        long id = dbb.insert(myDbHelper.TABLE_NAME, null , contentValues);
        return id;
    }

    public String getData(String search_id)
    {   System.out.println("get Data");


        SQLiteDatabase db = myhelper.getWritableDatabase();
        String[] columns = {myDbHelper.UID,myDbHelper.AGE,myDbHelper.GENDER,myDbHelper.TOT_BIL,myDbHelper.DIR_BIL,myDbHelper.ALK_PHO,myDbHelper.ALA_AMINO,myDbHelper.ASP_AMINO,myDbHelper.RESULT};

        Cursor cursor=db.query(myDbHelper.TABLE_NAME,columns,"pid=?",new String[]{search_id},null,null,null );
        //https://stackoverflow.com/questions/9185441/sqlite-query-method-where-clause-is-only-taking-double-quotes-strings

        //Intent i =new Intent(dummy_show.class);
        StringBuffer buffer= new StringBuffer();
        while (cursor.moveToNext())
        {
            String pid =cursor.getString(cursor.getColumnIndex(myDbHelper.UID));
            String age =cursor.getString(cursor.getColumnIndex(myDbHelper.AGE));
            String  gender =cursor.getString(cursor.getColumnIndex(myDbHelper.GENDER));
            String  tot_bil =cursor.getString(cursor.getColumnIndex(myDbHelper.TOT_BIL));
            String  dir_bil =cursor.getString(cursor.getColumnIndex(myDbHelper.DIR_BIL));
            String  alk_pho =cursor.getString(cursor.getColumnIndex(myDbHelper.ALK_PHO));
            String  ala_amino =cursor.getString(cursor.getColumnIndex(myDbHelper.ALA_AMINO));
            String  asp_amino =cursor.getString(cursor.getColumnIndex(myDbHelper.ASP_AMINO));
            String  result =cursor.getString(cursor.getColumnIndex(myDbHelper.RESULT));
             if(gender.equalsIgnoreCase("1")){gender="Female";}
            else if (gender.equalsIgnoreCase("0")) { gender="Male";}
            System.out.println("geting data"+result);
            buffer.append("Patient ID:"+pid+"\n"+"Age:"+age+"\n"+ "Gender:"+ gender +" \n"+"Total Bilirubin:"+tot_bil+"\n"+"Direct Bilirubin:"+dir_bil+"\n"+"Alkaline Phosphotase:"+alk_pho+"\n"+"Alamine Aminotransferase:"+ala_amino+"\n"+"Asparatate Aminotransferace:"+asp_amino+"\n\n\n"+"RESULT:"+result+"\n\n\n\n");
        }
        //1-positive
        //2-negative
        //0-male,  1-female
        System.out.println(buffer.toString());
        return buffer.toString();
    }

    //doctor
    public String getData_docter()
    {
        SQLiteDatabase db = myhelper.getWritableDatabase();
        String[] columns = {myDbHelper.UID,myDbHelper.AGE,myDbHelper.GENDER,myDbHelper.TOT_BIL,myDbHelper.DIR_BIL,myDbHelper.ALK_PHO,myDbHelper.ALA_AMINO,myDbHelper.ASP_AMINO,myDbHelper.RESULT};

        Cursor cursor=db.query(myDbHelper.TABLE_NAME,columns,null,null,null,null,null );
        //https://stackoverflow.com/questions/9185441/sqlite-query-method-where-clause-is-only-taking-double-quotes-strings

        //Intent i =new Intent(dummy_show.class);
        StringBuffer buffer= new StringBuffer();
        while (cursor.moveToNext())
        {
            String pid =cursor.getString(cursor.getColumnIndex(myDbHelper.UID));
            String age =cursor.getString(cursor.getColumnIndex(myDbHelper.AGE));
            String  gender =cursor.getString(cursor.getColumnIndex(myDbHelper.GENDER));
            String  tot_bil =cursor.getString(cursor.getColumnIndex(myDbHelper.TOT_BIL));
            String  dir_bil =cursor.getString(cursor.getColumnIndex(myDbHelper.DIR_BIL));
            String  alk_pho =cursor.getString(cursor.getColumnIndex(myDbHelper.ALK_PHO));
            String  ala_amino =cursor.getString(cursor.getColumnIndex(myDbHelper.ALA_AMINO));
            String  asp_amino =cursor.getString(cursor.getColumnIndex(myDbHelper.ASP_AMINO));
            String  result =cursor.getString(cursor.getColumnIndex(myDbHelper.RESULT));

            if(gender.equalsIgnoreCase("1")){gender="Female";}
            else if (gender.equalsIgnoreCase("0")) { gender="Male";}

            Log.e("value in doctor",result);

            buffer.append("Patient ID:"+pid+"\n"+"Age:"+age+"\n"+ "Gender:"+ gender +" \n"+"Total Bilirubin:"+tot_bil+"\n"+"Direct Bilirubin:"+dir_bil+"\n"+"Alkaline Phosphotase:"+alk_pho+"\n"+"Alamine Aminotransferase:"+ala_amino+"\n"+"Asparatate Aminotransferace:"+asp_amino+"\n\n\n"+"RESULT:"+result+"\n\n-----------------------------------------------------------\n\n");
        }
        return buffer.toString();
    }

    public  int delete(String pid)
    {
        SQLiteDatabase db = myhelper.getWritableDatabase();
        String[] whereArgs ={pid};

        int count =db.delete(myDbHelper.TABLE_NAME ,myDbHelper.UID+" = ?",whereArgs);
        return  count;
    }

    /*public int updateName(String oldName , String newName)
    {
        SQLiteDatabase db = myhelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(myDbHelper.NAME,newName);
        String[] whereArgs= {oldName};
        int count =db.update(myDbHelper.TABLE_NAME,contentValues, myDbHelper.NAME+" = ?",whereArgs );
        return count;
    }*/

    static class myDbHelper extends SQLiteOpenHelper
    {
        private static final String DATABASE_NAME = "myDatabase";    // Database Name
        private static final String TABLE_NAME = "myTable";   // Table Name
        private static final int DATABASE_Version = 1;    // Database Version
        private static final String UID="pid";     // Column I (Primary Key)
        private static final String AGE = "age";    //Column II
        private static final String GENDER= "gender";    // Column III
        private static final String TOT_BIL= "tot_bil";
        private static final String DIR_BIL= "dir_bil";
        private static final String ALK_PHO= "alk_pho";
        private static final String ALA_AMINO= "ala_amino";
        private static final String ASP_AMINO= "asp_amino";
        private static final String RESULT= "result";

        private static final String CREATE_TABLE = "CREATE TABLE "+TABLE_NAME+
                " ("+UID+" REAL , "+AGE+" REAL ,"+ GENDER+" REAL,"+TOT_BIL+" REAL,"+DIR_BIL+" REAL,"+ALK_PHO+" REAL,"+ALA_AMINO+" REAL,"+ASP_AMINO+" REAL,"+RESULT+" VARCHAR(30));";
        private static final String DROP_TABLE ="DROP TABLE IF EXISTS "+TABLE_NAME;
        private Context context;

        public myDbHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_Version);
            this.context=context;
        }

        public void onCreate(SQLiteDatabase db) {

            try {
                db.execSQL(CREATE_TABLE);
            } catch (Exception e) {
                Message.message(context,""+e);
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            try {
                Message.message(context,"OnUpgrade");
                db.execSQL(DROP_TABLE);
                onCreate(db);
            }catch (Exception e) {
                Message.message(context,""+e);
            }
        }
    }
}
