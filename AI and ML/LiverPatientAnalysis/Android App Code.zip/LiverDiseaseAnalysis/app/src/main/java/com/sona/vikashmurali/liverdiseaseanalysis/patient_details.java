package com.sona.vikashmurali.liverdiseaseanalysis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class patient_details extends AppCompatActivity {
    Button predict_btn,report_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_details);

        predict_btn=(Button)findViewById(R.id.predict_btn);
        report_btn=(Button)findViewById(R.id.report_btn);

        predict_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(view.getContext(),prediction.class);
                startActivity(intent);
            }
        });

        report_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(),show_report.class);
                startActivity(intent);

            }
        });
    }
}
