package com.sona.vikashmurali.liverdiseaseanalysis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class patient_login extends AppCompatActivity {
    EditText patient_id;
    Button login;
    TextView error_msg;
    SharedPreferences sp;
   String pid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_login);

        sp = getSharedPreferences("patient_login", MODE_PRIVATE);

        patient_id=(EditText)findViewById(R.id.patient_id);

        login=(Button)findViewById(R.id.logind);
        error_msg=(TextView)findViewById(R.id.login_error);

        pid=patient_id.getText().toString();
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //||pid.equalsIgnoreCase("patient2") ||pid.equalsIgnoreCase("patient3") ||pid.equalsIgnoreCase("patient4") ||pid.equals("patient5")
                if (patient_id.getText().toString().equalsIgnoreCase("patient1") || patient_id.getText().toString().equalsIgnoreCase("patient2") ||patient_id.getText().toString().equalsIgnoreCase("patient3")||patient_id.getText().toString().equalsIgnoreCase("patient4")||patient_id.getText().toString().equalsIgnoreCase("patient5")) {

                    SharedPreferences.Editor editor = sp.edit();
                    editor.putString("pid", patient_id.getText().toString());
                    editor.apply();
                    Toast.makeText(getApplicationContext(), sp.getString("pid","sona"), Toast.LENGTH_LONG).show();
                    Log.d("patient id @@@@@@",pid.toString());


                    Intent intent = new Intent(view.getContext(), patient_details.class);
                    startActivity(intent);
                } else {
                    error_msg.setText("Invalid patient ID!");
                }
            }
        });


    }
}