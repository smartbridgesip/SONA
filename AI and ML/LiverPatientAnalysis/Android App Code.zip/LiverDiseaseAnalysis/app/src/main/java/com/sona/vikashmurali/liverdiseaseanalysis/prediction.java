package com.sona.vikashmurali.liverdiseaseanalysis;

// insert data page

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;

import javax.net.ssl.HttpsURLConnection;






import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import java.util.Base64;
import android.util.Log;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import android.widget.Toast;


public class prediction extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener {
    //String final_result="";
    //String result;
    EditText age,total_bilirubin,direct_bilirubin,alkaline_phosphotase,alamine_amino,aspartate_amino;
    float iage,itot_bil,idir_bil,ialk_pho,iala_amino,iasp_amino,igender;
    String sresult="";
    Button predict_btn;
    myDbAdapter helper;
    SharedPreferences sp ;
    String ipid;
    String gender[] = {"Male", "Female"};
    Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prediction);
        Log.d("first","starting app--------");
        helper = new myDbAdapter(this);
        sp = getSharedPreferences("patient_login", MODE_PRIVATE);
        //result=(TextView)findViewById(R.id.tresult);
        spinner=(Spinner)findViewById(R.id.spinner);
        age=(EditText)findViewById(R.id.age);
        total_bilirubin=(EditText)findViewById(R.id.tot_bil);
        direct_bilirubin=(EditText)findViewById(R.id.dir_bil);
        alkaline_phosphotase=(EditText)findViewById(R.id.alk_pho);
        alamine_amino=(EditText)findViewById(R.id.alam);
        aspartate_amino=(EditText)findViewById(R.id.aspa);

        predict_btn=(Button)findViewById(R.id.pred);

        //predict button
        predict_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ipid=sp.getString("pid", "sona");
                iage = Float.parseFloat(age.getText().toString());
                itot_bil= Float.parseFloat(total_bilirubin.getText().toString());
                idir_bil = Float.parseFloat(direct_bilirubin.getText().toString());
                ialk_pho = Float.parseFloat(alkaline_phosphotase.getText().toString());
                iala_amino = Float.parseFloat(alamine_amino.getText().toString());
                iasp_amino = Float.parseFloat(aspartate_amino.getText().toString());
                d d1=new d();
                d1.execute();
                //result.setText(final_result);
                //iresult=Float.parseFloat(result.toString());
                //Log.e("final result ----",final_result);
                //result.setText(response.toString());
                //addUser(sresult);
            }
        });

        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, gender);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spinner.setAdapter(aa);

        Spinner spin = (Spinner) findViewById(R.id.spinner);
        spin.setOnItemSelectedListener(this);

    }
    /*private void connection() {
        Log.i("first","starting conn--------");
        Log.i("first","@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@--------");
    }*/


    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
        Toast.makeText(getApplicationContext(), gender[position], Toast.LENGTH_LONG).show();
        if(gender[position].equalsIgnoreCase("Male")){igender=0;}
        else if (gender[position].equalsIgnoreCase("Female")){igender=1;}
    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }



    private void addUser(String sresult) {

        System.out.println("add user"+sresult);

        if(total_bilirubin.getText().toString().isEmpty() || direct_bilirubin.getText().toString().isEmpty() || alkaline_phosphotase.getText().toString().isEmpty())
        {
            Message.message(getApplicationContext(),"Enter All Required Valuess");
        }
        else
        {
            long del_id=helper.delete(ipid);
            if(del_id<=0) {

                long id = helper.insertData(ipid, iage, igender, itot_bil, idir_bil, ialk_pho, iala_amino, iasp_amino, sresult);
                if (id <= 0) {
                    Message.message(getApplicationContext(), "Please re-enter the values");

                } else {
                    Message.message(getApplicationContext(), "GO TO REPORT TO SEE YOUR REPORT");

                }
            }
        }
    }


    public class d extends AsyncTask<Void,Void,Void> {
        private Context context;
//        public data_flow(Context context) {
//            this.context = context;
//        }
        //HttpURLConnection urlConnection;


        @RequiresApi(api = Build.VERSION_CODES.O)
        @Override
        protected Void doInBackground(Void... voids) {


            //String srresult="";
            //Log.e("start","do in back");

            try {

                String url = "https://tamchikki.eu-gb.mybluemix.net/send?Age="+iage+"&Total_Bilirubin="+itot_bil+"&Direct_Bilirubin="+idir_bil+"&Alkaline_Phosphotase="+ialk_pho+"&Alamine_Aminotransferase="+iala_amino+"&Aspartate_Aminotransferase="+iasp_amino;

                URL obj = new URL(url);
                HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
                con.setRequestMethod("GET");

                Log.e("start","");

                int responseCode = con.getResponseCode();
                System.out.println("\nSending 'GET' request to URL : " + url);
                //System.out.println("Post parameters : " + urlParameters);
                System.out.println("Response Code : " + responseCode);
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                //print result
                System.out.println(response.toString());
                sresult = response.toString();
                //System.out.println(sresult);


                con.disconnect();

            } catch (IOException ioe) {
                ioe.printStackTrace();


            }


            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            addUser(sresult);
        }
    }

}
