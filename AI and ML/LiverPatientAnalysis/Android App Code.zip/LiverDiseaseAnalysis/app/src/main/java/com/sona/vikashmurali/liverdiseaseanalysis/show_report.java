package com.sona.vikashmurali.liverdiseaseanalysis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class show_report extends AppCompatActivity {
    TextView text;
    myDbAdapter helper;
    SharedPreferences sp ;
    String ipid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_report);
        text=(TextView)findViewById(R.id.show);
        helper = new myDbAdapter(this);
        sp = getSharedPreferences("patient_login", MODE_PRIVATE);
        ipid=sp.getString("pid","sona");
        viewdata();


    }
    public void viewdata()
    {
        System.out.println("show data report");

        String data = helper.getData(ipid);
        text.setText(data);
    }
}
